import React from 'react';
import ImageUpload from './components/ImageUpload';
import './App.css';

const App = () => {
    return (
        <div className="App">
            <ImageUpload />
        </div>
    );
};

export default App;
