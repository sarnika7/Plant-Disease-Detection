import React, { useState } from 'react';
import axios from 'axios';
import './ImageUpload.css';

const ImageUpload = () => {
    const [file, setFile] = useState(null);
    const [uploadedFileURL, setUploadedFileURL] = useState('');
    const [prediction, setPrediction] = useState(''); // State to hold the prediction

    const handleFileChange = (event) => {
        setFile(event.target.files[0]);
    };

    const handleSubmit = async (event) => {
        event.preventDefault();
        const formData = new FormData();
        formData.append('image', file);

        try {
            const response = await axios.post('http://localhost:3200/api/upload', formData, {
                headers: {
                    'Content-Type': 'multipart/form-data',
                },
            });
            setUploadedFileURL(response.data.fileUrl); // Set the uploaded file URL
            setPrediction(response.data.prediction); // Set the prediction from the response
        } catch (error) {
            console.error("Error uploading file: ", error);
        }
    };

    return (
        <div>
            <h1>Upload Image</h1>
            <form onSubmit={handleSubmit}>
                <input type="file" accept="image/*" onChange={handleFileChange} />
                <button type="submit">Upload</button>
            </form>
            {uploadedFileURL && <img src={uploadedFileURL} alt="Uploaded" style={{ maxWidth: '300px', marginTop: '20px' }} />}
            {prediction && <h2>Predicted Class: {prediction}</h2>} {/* Display the prediction */}
        </div>
    );
};

export default ImageUpload;