// server/server.js
/*const express = require('express');
const cors = require('cors');
const apiRoutes = require('./routes/api'); // Import the API routes

const app = express();
const PORT = 5001;

app.use(cors());
app.use(express.json());

// Use the API routes
app.use('/api', apiRoutes);

app.listen(PORT, () => {
    console.log(`Server is running on http://localhost:${PORT}`);
});*/
// server.js
const express = require('express');
const cors = require('cors');
const apiRoutes = require('./routes/api'); // Import the API routes

const app = express();
const PORT = 3200;

// Middleware
app.use(cors());
app.use(express.json());

// Use the API routes
app.use('/api', apiRoutes);

// Serve static files from the uploads directory
app.use('/uploads', express.static('uploads'));

// Start the server
app.listen(PORT, () => {
    console.log(`Server is running on http://localhost:${PORT}`);
});