# server/models/model.py
import sys
import torch
from torchvision import transforms
from PIL import Image
from model_definition import Plant_Disease_Model2

# Define a mapping of class indices to class names
class_mapping = {
    1: 'Orange___Haunglongbing_(Citrus_greening)',
    2: 'Apple___Apple_scab',
    3: 'Apple___Black_rot',
    4: 'Apple___Cedar_apple_rust',
    5: 'Apple___healthy',
    6: 'Blueberry___healthy',
    7: 'Cherry_(including_sour)___healthy',
    8: 'Cherry_(including_sour)___Powdery_mildew',
    9: 'Grape___Black_rot',
    10: 'Grape___Esca_(Black_Measles)',
    11: 'Grape___healthy',
    12: 'Grape___Leaf_blight_(Isariopsis_Leaf_Spot)',
    13: 'Peach___Bacterial_spot',
    14: 'Peach___healthy',
    15: 'Pepper,_bell___Bacterial_spot',
    16: 'Pepper,_bell___healthy',
    17: 'Potato___Early_blight',
    18: 'Potato___healthy',
    19: 'Potato___Late_blight',
    20: 'Raspberry___healthy',
    21: 'Soybean___healthy',
    22: 'Squash___Powdery_mildew',
    23: 'Strawberry___healthy',
    24: 'Strawberry___Leaf_scorch',
    25: 'Tomato___Bacterial_spot',
    26: 'Tomato___Early_blight',
    27: 'Tomato___healthy',
    28: 'Tomato___Late_blight',
    29: 'Tomato___Leaf_Mold',
    30: 'Tomato___Septoria_leaf_spot',
    31: 'Tomato___Spider_mites Two-spotted_spider_mite',
    32: 'Tomato___Target_Spot',
    33: 'Tomato___Tomato_mosaic_virus',
    34: 'Tomato___Tomato_Yellow_Leaf_Curl_Virus'
}

model = Plant_Disease_Model2()  # Initialize your model

# Load the state dictionary
model.load_state_dict(torch.load("/Users/meena/Desktop/plant disease/proj-2/plant_disease_model.pth", map_location=torch.device('cpu')))
model.eval()  # Set the model to evaluation mode

# Define the image transformation
transform = transforms.Compose([
    transforms.Resize((224, 224)),  # Adjust size as needed
    transforms.ToTensor(),
])

# Load the image and make a prediction
image_path = sys.argv[1]
image = Image.open(image_path)
image = transform(image).unsqueeze(0)  # Add batch dimension

with torch.no_grad():
    output = model(image)
    _, predicted = torch.max(output, 1)
    
    # Get the predicted class index
    predicted_class_index = predicted.item()
    
    # Get the class name from the mapping
    prediction_label = class_mapping.get(predicted_class_index, 'Unknown Class')  # Default to 'Unknown Class' if not found

print(prediction_label)  # Output the prediction

'''import torch
print(torch.__version__)'''