import torch
import torch.nn as nn
import torch.nn.functional as F
from torchvision import models
from torchvision.models import resnet34, ResNet34_Weights

class AttentionLayer(nn.Module):
    def __init__(self, input_dim):
        super(AttentionLayer, self).__init__()
        self.W = nn.Linear(input_dim, input_dim)
        self.V = nn.Linear(input_dim, 1)

    def forward(self, x):
        # Compute attention scores
        scores = self.V(torch.tanh(self.W(x)))
        attention_weights = F.softmax(scores, dim=1)
        
        # Apply attention weights
        context = attention_weights * x
        return context.sum(dim=1)  # Aggregate context

class Plant_Disease_Model2(nn.Module):
    def __init__(self):
        super(Plant_Disease_Model2, self).__init__()
        self.network = resnet34(weights=ResNet34_Weights.IMAGENET1K_V1)
        num_ftrs = self.network.fc.in_features
        self.network.fc = nn.Identity()  # Remove the final layer
        self.attention = AttentionLayer(num_ftrs)  # Add attention layer
        self.fc = nn.Linear(num_ftrs, 38)  # Final classification layer

    def forward(self, xb):
        out = self.network(xb)  # Get features from ResNet
        out = self.attention(out.unsqueeze(1))  # Apply attention
        out = self.fc(out)  # Classify
        return out

    def training_step(self, batch):
        images, labels = batch
        out = self(images)  # Forward pass
        loss = F.cross_entropy(out, labels)  # Compute loss
        return loss

    def validation_step(self, batch):
        images, labels = batch
        out = self(images)  # Forward pass
        loss = F.cross_entropy(out, labels)  # Compute loss
        acc = accuracy(out, labels)  # Compute accuracy
        return {'val_loss': loss, 'val_acc': acc}

    def validation_epoch_end(self, outputs):
        batch_loss = [out['val_loss'] for out in outputs]
        epoch_loss = torch.stack(batch_loss).mean()
        batch_acc = [out['val_acc'] for out in outputs]
        epoch_acc = torch.stack(batch_acc).mean()
        return {'val_loss': epoch_loss.item(), 'val_acc': epoch_acc.item()}

    def epoch_end(self, epoch, result):
        print(f"Epoch [{epoch}], Train Loss: {result['train_loss']:.4f}, Val Loss: {result['val_loss']:.4f}, Val Acc: {result['val_acc']:.4f}")

# Helper function to compute accuracy
def accuracy(outputs, labels):
    _, preds = torch.max(outputs, dim=1)
    return torch.tensor(torch.sum(preds == labels).item() / len(preds))
