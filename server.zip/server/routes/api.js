// routes/api.js
const express = require('express');
const multer = require('multer');
const path = require('path');
const { exec } = require('child_process'); // Import exec to run Python scripts

const router = express.Router();

// Set up storage for multer
const storage = multer.diskStorage({
    destination: (req, file, cb) => {
        cb(null, 'uploads/'); // Ensure this directory exists
    },
    filename: (req, file, cb) => {
        cb(null, Date.now() + path.extname(file.originalname)); // Append timestamp to filename
    },
});

const upload = multer({ storage });

// Route for uploading images
router.post('/upload', upload.single('image'), (req, res) => {
    console.log('Received file:', req.file); // Log the received file
    if (!req.file) {
        console.error('No file uploaded.');
        return res.status(400).send('No file uploaded.');
    }

    const fileUrl = `http://localhost:3200/uploads/${req.file.filename}`;
    console.log('File URL:', fileUrl); // Log the file URL

    // Call the Python script for prediction
    exec(`python3 "/Users/meena/Desktop/plant disease/proj-2/plant-disease-app/server/models/model.py" "${req.file.path}"`, (error, stdout, stderr) => {
        if (error) {
            console.error(`Error executing Python script: ${error}`);
            return res.status(500).json({ error: 'Prediction failed' });
        }
        
        // The prediction output from the Python script
        const prediction = stdout.trim(); // Get the prediction from stdout
        console.log('Prediction:', prediction); // Log the prediction

        // Send back the file URL and prediction
        res.json({ fileUrl, prediction });
    });
});

module.exports = router;